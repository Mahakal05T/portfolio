import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AnimatedBackground } from './components/ui/AnimatedBackground';
import { Portfolio } from './components/sections/Portfolio';
import { Admin } from './components/sections/Admin';
import { VisitorTracker } from './components/analytics/VisitorTracker';

function App() {
  return (
    <div className="min-h-screen text-gray-200">
      <VisitorTracker />
      <Toaster 
        position="bottom-right"
        toastOptions={{
          style: {
            background: '#1a1a2e',
            color: '#fff',
            border: '1px solid rgba(255, 255, 255, 0.1)',
          },
          success: {
            iconTheme: {
              primary: '#4ade80',
              secondary: '#1a1a2e',
            },
          },
          error: {
            iconTheme: {
              primary: '#f87171',
              secondary: '#1a1a2e',
            },
          },
        }}
      />
      <AnimatedBackground />
      <Routes>
        <Route path="/" element={<Portfolio />} />
        <Route path="/dashboard-panel" element={<Admin />} />
      </Routes>
    </div>
  );
}

export default App;
